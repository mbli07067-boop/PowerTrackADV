/* =========================
   POWERTRACK
   MAIN JAVASCRIPT
========================= */


/* =========================
   VARIABLES
========================= */

let profile = JSON.parse(
  localStorage.getItem("powerTrackProfile")
) || null;


let foods = JSON.parse(
  localStorage.getItem("powerTrackFoods")
) || [];


let weightHistory = JSON.parse(
  localStorage.getItem("weightHistory")
) || [];


let strengthHistory = JSON.parse(
  localStorage.getItem("strengthHistory")
) || [];


let targets = JSON.parse(
  localStorage.getItem("nutritionTargets")
) || null;


let workoutPlan = JSON.parse(
  localStorage.getItem("workoutPlan")
) || null;


let weightChart;
let strengthChart;


/* =========================
   DOM ELEMENTS
========================= */

const onboarding =
  document.getElementById("onboarding");

const app =
  document.getElementById("app");

const trainingType =
  document.getElementById("trainingType");

const powerliftingInputs =
  document.getElementById("powerliftingInputs");


/* =========================
   SHOW POWERLIFTING INPUTS
========================= */

trainingType.addEventListener(
  "change",
  () => {

    if (
      trainingType.value ===
      "powerlifting"
    ) {

      powerliftingInputs.classList.remove(
        "hidden"
      );

    } else {

      powerliftingInputs.classList.add(
        "hidden"
      );

    }

  }
);


/* =========================
   INITIALIZE APP
========================= */

function initializeApp() {

  if (profile) {

    onboarding.classList.add(
      "hidden"
    );

    app.classList.remove(
      "hidden"
    );

    loadApp();

  }

}


/* =========================
   PROFILE FORM
========================= */

document
  .getElementById("profileForm")
  .addEventListener(
    "submit",
    function (event) {

      event.preventDefault();


      const selectedDays =
        Array.from(
          document.querySelectorAll(
            ".days-grid input:checked"
          )
        ).map(
          input => input.value
        );


      const daysCount =
        Number(
          document.getElementById(
            "trainingDays"
          ).value
        );


      if (
        selectedDays.length !==
        daysCount
      ) {

        alert(
          `Please select exactly ${daysCount} training days.`
        );

        return;

      }


      profile = {

        name:
          document
            .getElementById("name")
            .value,

        age:
          Number(
            document
              .getElementById("age")
              .value
          ),

        gender:
          document
            .getElementById("gender")
            .value,

        height:
          Number(
            document
              .getElementById("height")
              .value
          ),

        weight:
          Number(
            document
              .getElementById("weight")
              .value
          ),

        level:
          document
            .getElementById("level")
            .value,

        trainingType:
          document
            .getElementById("trainingType")
            .value,

        bench:
          Number(
            document
              .getElementById("bench")
              .value
          ) || 0,

        squat:
          Number(
            document
              .getElementById("squat")
              .value
          ) || 0,

        deadlift:
          Number(
            document
              .getElementById("deadlift")
              .value
          ) || 0,

        trainingDays:
          selectedDays

      };


      /* CREATE DEFAULT TARGETS */

      targets = {

        calories:
          calculateCalories(),

        protein:
          Math.round(
            profile.weight * 2
          ),

        carbs:
          Math.round(
            profile.weight * 3
          ),

        fat:
          Math.round(
            profile.weight * 0.8
          )

      };


      /* CREATE WORKOUT */

      workoutPlan =
        generateWorkoutPlan();


      /* SAVE DATA */

      saveAll();


      /* OPEN APP */

      onboarding.classList.add(
        "hidden"
      );

      app.classList.remove(
        "hidden"
      );


      loadApp();

    }
  );


/* =========================
   CALCULATE CALORIES
========================= */

function calculateCalories() {

  let bmr;


  if (
    profile.gender === "male"
  ) {

    bmr =

      10 * profile.weight +

      6.25 * profile.height -

      5 * profile.age +

      5;

  } else {

    bmr =

      10 * profile.weight +

      6.25 * profile.height -

      5 * profile.age -

      161;

  }


  return Math.round(

    bmr * 1.55

  );

}


/* =========================
   GENERATE WORKOUT
========================= */

function generateWorkoutPlan() {

  if (
    profile.trainingType ===
    "powerlifting"
  ) {

    return generatePowerliftingPlan();

  }

  return generateBodybuildingPlan();

}


/* =========================
   POWERLIFTING PLAN
========================= */

function generatePowerliftingPlan() {

  const days =
    profile.trainingDays;


  const plan = {};


  const benchWeight =
    Math.round(
      profile.bench * 0.8
    );


  const squatWeight =
    Math.round(
      profile.squat * 0.8
    );


  const deadliftWeight =
    Math.round(
      profile.deadlift * 0.8
    );


  const workouts = [

    {

      title:
        "Squat Focus",

      exercises: [

        {
          name:
            "Squat",

          sets: 5,

          reps: 5,

          weight:
            squatWeight,

          rpe: 7

        },

        {
          name:
            "Romanian Deadlift",

          sets: 3,

          reps: 8,

          weight:
            "Moderate",

          rpe: 7

        },

        {
          name:
            "Leg Press",

          sets: 3,

          reps: 10,

          weight:
            "Moderate",

          rpe: 8

        },

        {
          name:
            "Core",

          sets: 3,

          reps: 15,

          weight:
            "Bodyweight",

          rpe: 7

        }

      ]

    },


    {

      title:
        "Bench Focus",

      exercises: [

        {
          name:
            "Bench Press",

          sets: 5,

          reps: 5,

          weight:
            benchWeight,

          rpe: 7

        },

        {
          name:
            "Rows",

          sets: 4,

          reps: 8,

          weight:
            "Moderate",

          rpe: 8

        },

        {
          name:
            "Shoulder Press",

          sets: 3,

          reps: 8,

          weight:
            "Moderate",

          rpe: 7

        },

        {
          name:
            "Triceps",

          sets: 3,

          reps: 12,

          weight:
            "Moderate",

          rpe: 8

        }

      ]

    },


    {

      title:
        "Deadlift Focus",

      exercises: [

        {
          name:
            "Deadlift",

          sets: 3,

          reps: 3,

          weight:
            deadliftWeight,

          rpe: 8

        },

        {
          name:
            "Lat Pulldown",

          sets: 4,

          reps: 10,

          weight:
            "Moderate",

          rpe: 8

        },

        {
          name:
            "Biceps",

          sets: 3,

          reps: 12,

          weight:
            "Moderate",

          rpe: 8

        }

      ]

    },

    {

      title:
        "Upper Body Volume",

      exercises: [

        {
          name:
            "Bench Press",

          sets: 4,

          reps: 8,

          weight:
            Math.round(
              profile.bench * 0.65
            ),

          rpe: 7

        },

        {
          name:
            "Rows",

          sets: 4,

          reps: 10,

          weight:
            "Moderate",

          rpe: 8

        },

        {
          name:
            "Shoulder Press",

          sets: 3,

          reps: 10,

          weight:
            "Moderate",

          rpe: 8

        }

      ]

    },


    {

      title:
        "Lower Body Volume",

      exercises: [

        {
          name:
            "Squat",

          sets: 4,

          reps: 8,

          weight:
            Math.round(
              profile.squat * 0.65
            ),

          rpe: 7

        },

        {
          name:
            "Romanian Deadlift",

          sets: 3,

          reps: 10,

          weight:
            "Moderate",

          rpe: 8

        },

        {
          name:
            "Leg Press",

          sets: 4,

          reps: 12,

          weight:
            "Moderate",

          rpe: 8

        }

      ]

    }

  ];


  days.forEach(
    (day, index) => {

      plan[day] =

        workouts[
          index %
          workouts.length
        ];

    }
  );


  return plan;

}


/* =========================
   BODYBUILDING PLAN
========================= */

function generateBodybuildingPlan() {

  const days =
    profile.trainingDays;


  const plan = {};


  const workouts = [

    {

      title:
        "Chest + Triceps",

      exercises: [

        {
          name:
            "Bench Press",

          sets: 4,

          reps: "8-12",

          rpe: 8

        },

        {
          name:
            "Incline Dumbbell Press",

          sets: 3,

          reps: "10-12",

          rpe: 8

        },

        {
          name:
            "Cable Fly",

          sets: 3,

          reps: "12-15",

          rpe: 9

        },

        {
          name:
            "Triceps Pushdown",

          sets: 3,

          reps: "10-15",

          rpe: 8

        }

      ]

    },


    {

      title:
        "Back + Biceps",

      exercises: [

        {
          name:
            "Lat Pulldown",

          sets: 4,

          reps: "8-12",

          rpe: 8

        },

        {
          name:
            "Barbell Row",

          sets: 4,

          reps: "8-10",

          rpe: 8

        },

        {
          name:
            "Seated Row",

          sets: 3,

          reps: "10-12",

          rpe: 8

        },

        {
          name:
            "Biceps Curl",

          sets: 3,

          reps: "10-15",

          rpe: 9

        }

      ]

    },


    {

      title:
        "Leg Day",

      exercises: [

        {
          name:
            "Squat",

          sets: 4,

          reps: "6-10",

          rpe: 8

        },

        {
          name:
            "Leg Press",

          sets: 4,

          reps: "10-12",

          rpe: 9

        },

        {
          name:
            "Leg Curl",

          sets: 3,

          reps: "10-15",

          rpe: 9

        },

        {
          name:
            "Calf Raises",

          sets: 4,

          reps: "12-20",

          rpe: 9

        }

      ]

    },


    {

      title:
        "Shoulders + Arms",

      exercises: [

        {
          name:
            "Shoulder Press",

          sets: 4,

          reps: "8-12",

          rpe: 8

        },

        {
          name:
            "Lateral Raises",

          sets: 4,

          reps: "12-20",

          rpe: 9

        },

        {
          name:
            "Biceps Curl",

          sets: 3,

          reps: "10-15",

          rpe: 9

        },

        {
          name:
            "Triceps Extension",

          sets: 3,

          reps: "10-15",

          rpe: 9

        }

      ]

    },


    {

      title:
        "Full Body",

      exercises: [

        {
          name:
            "Bench Press",

          sets: 3,

          reps: "8-10",

          rpe: 8

        },

        {
          name:
            "Lat Pulldown",

          sets: 3,

          reps: "10-12",

          rpe: 8

        },

        {
          name:
            "Leg Press",

          sets: 3,

          reps: "10-15",

          rpe: 8

        }

      ]

    }

  ];


  days.forEach(
    (day, index) => {

      plan[day] =

        workouts[
          index %
          workouts.length
        ];

    }
  );


  return plan;

}


/* =========================
   LOAD APP
========================= */

function loadApp() {

  document
    .getElementById("welcomeText")
    .textContent =

    `Welcome, ${profile.name}`;


  renderDashboard();

  renderWorkout();

  renderFood();

  renderProfile();

  renderWeightChart();

  renderStrengthChart();

}


/* =========================
   DASHBOARD
========================= */

function renderDashboard() {

  const totals =
    calculateFoodTotals();


  const currentWeight =

    weightHistory.length > 0

      ? weightHistory[
          weightHistory.length - 1
        ].weight

      : profile.weight;


  document
    .getElementById("currentWeight")
    .textContent =
    currentWeight;


  document
    .getElementById("consumedCalories")
    .textContent =
    totals.calories;


  document
    .getElementById("calorieTarget")
    .textContent =
    targets.calories;


  document
    .getElementById("remainingCalories")
    .textContent =
    Math.max(
      targets.calories -
      totals.calories,
      0
    );


  document
    .getElementById("consumedProtein")
    .textContent =
    totals.protein;


  document
    .getElementById("proteinTarget")
    .textContent =
    targets.protein;


  document
    .getElementById("remainingProtein")
    .textContent =
    Math.max(
      targets.protein -
      totals.protein,
      0
    );


  /* Progress Bars */

  const caloriePercent =

    Math.min(

      (
        totals.calories /
        targets.calories
      ) * 100,

      100

    );


  const proteinPercent =

    Math.min(

      (
        totals.protein /
        targets.protein
      ) * 100,

      100

    );


  document
    .getElementById("calorieProgress")
    .style.width =
    caloriePercent + "%";


  document
    .getElementById("proteinProgress")
    .style.width =
    proteinPercent + "%";


  /* Today's Workout */

  const today =
    new Date()
      .toLocaleDateString(
        "en-US",
        {
          weekday:
            "long"
        }
      );


  const todayWorkout =
    document.getElementById(
      "todayWorkout"
    );


  if (
    workoutPlan[today]
  ) {

    todayWorkout.innerHTML = `

      <h3>
        ${workoutPlan[today].title}
      </h3>

      <p>
        ${workoutPlan[today]
          .exercises
          .map(
            exercise =>
              exercise.name
          )
          .join(" • ")
        }
      </p>

    `;

  } else {

    todayWorkout.innerHTML = `

      Rest Day 😴

    `;

  }

}


/* =========================
   RENDER WORKOUT
========================= */

function renderWorkout() {

  const container =
    document.getElementById(
      "workoutPlan"
    );


  container.innerHTML = "";


  Object.keys(
    workoutPlan
  ).forEach(
    day => {

      const workout =
        workoutPlan[day];


      const dayElement =
        document.createElement(
          "div"
        );


      dayElement.className =
        "workout-day";


      dayElement.innerHTML = `

        <h2>
          ${day}
        </h2>

        <h3>
          ${workout.title}
        </h3>

      `;


      workout.exercises.forEach(
        exercise => {

          const exerciseElement =
            document.createElement(
              "div"
            );


          exerciseElement.className =
            "exercise";


          exerciseElement.innerHTML = `

            <h4>
              ${exercise.name}
            </h4>

            <p>
              Sets:
              ${exercise.sets}
            </p>

            <p>
              Reps:
              ${exercise.reps}
            </p>

            <p>
              Weight:
              ${exercise.weight ?? "Choose Weight"}
              ${
                typeof exercise.weight === "number"
                  ? " kg"
                  : ""
              }
            </p>

            <p>
              RPE:
              ${exercise.rpe}
            </p>

          `;


          dayElement.appendChild(
            exerciseElement
          );

        }
      );


      container.appendChild(
        dayElement
      );

    }
  );

}


/* =========================
   FOOD FORM
========================= */

document
  .getElementById("foodForm")
  .addEventListener(
    "submit",
    function (event) {

      event.preventDefault();


      const food = {

        id:
          Date.now(),

        name:
          document
            .getElementById("foodName")
            .value,

        meal:
          document
            .getElementById("mealType")
            .value,

        calories:
          Number(
            document
              .getElementById("foodCalories")
              .value
          ),

        protein:
          Number(
            document
              .getElementById("foodProtein")
              .value
          ),

        carbs:
          Number(
            document
              .getElementById("foodCarbs")
              .value
          ),

        fat:
          Number(
            document
              .getElementById("foodFat")
              .value
          )

      };


      foods.push(
        food
      );


      saveAll();

      renderFood();

      renderDashboard();


      this.reset();

    }
  );


/* =========================
   CALCULATE FOOD TOTALS
========================= */

function calculateFoodTotals() {

  return foods.reduce(

    (
      totals,
      food
    ) => {

      totals.calories +=
        food.calories;

      totals.protein +=
        food.protein;

      totals.carbs +=
        food.carbs;

      totals.fat +=
        food.fat;


      return totals;

    },

    {

      calories: 0,

      protein: 0,

      carbs: 0,

      fat: 0

    }

  );

}


/* =========================
   RENDER FOOD
========================= */

function renderFood() {

  const container =
    document.getElementById(
      "foodList"
    );


  const totals =
    calculateFoodTotals();


  document
    .getElementById("nutritionCalories")
    .textContent =
    totals.calories;


  document
    .getElementById("nutritionProtein")
    .textContent =
    totals.protein;


  document
    .getElementById("nutritionCarbs")
    .textContent =
    totals.carbs;


  document
    .getElementById("nutritionFat")
    .textContent =
    totals.fat;


  container.innerHTML = "";


  if (
    foods.length === 0
  ) {

    container.innerHTML = `

      <p>
        No food added today.
      </p>

    `;

    return;

  }


  foods.forEach(
    food => {

      const foodElement =
        document.createElement(
          "div"
        );


      foodElement.className =
        "food-item";


      foodElement.innerHTML = `

        <div class="food-info">

          <strong>

            ${food.meal}:
            ${food.name}

          </strong>

          <span>

            🔥 ${food.calories} kcal

            🥩 ${food.protein}g Protein

            🍚 ${food.carbs}g Carbs

            🥑 ${food.fat}g Fat

          </span>

        </div>


        <button
          class="delete-food"
          onclick="
            deleteFood(
              ${food.id}
            )
          "
        >

          Delete

        </button>

      `;


      container.appendChild(
        foodElement
      );

    }
  );

}


/* =========================
   DELETE FOOD
========================= */

function deleteFood(id) {

  foods =
    foods.filter(
      food =>
        food.id !== id
    );


  saveAll();

  renderFood();

  renderDashboard();

}


/* =========================
   WEIGHT FORM
========================= */

document
  .getElementById("weightForm")
  .addEventListener(
    "submit",
    function (event) {

      event.preventDefault();


      const weight =
        Number(
          document
            .getElementById("newWeight")
            .value
        );


      weightHistory.push({

        date:
          new Date()
            .toLocaleDateString(),

        weight:
          weight

      });


      localStorage.setItem(

        "weightHistory",

        JSON.stringify(
          weightHistory
        )

      );


      renderDashboard();

      renderWeightChart();


      this.reset();

    }
  );


/* =========================
   WEIGHT CHART
========================= */

function renderWeightChart() {

  const canvas =
    document.getElementById(
      "weightChart"
    );


  if (
    weightChart
  ) {

    weightChart.destroy();

  }


  weightChart =
    new Chart(
      canvas,
      {

        type:
          "line",

        data: {

          labels:

            weightHistory.map(
              item =>
                item.date
            ),

          datasets: [

            {

              label:
                "Weight (kg)",

              data:

                weightHistory.map(
                  item =>
                    item.weight
                ),

              borderColor:
                "white",

              backgroundColor:
                "rgba(255,255,255,0.1)",

              tension:
                0.3

            }

          ]

        },

        options: {

          responsive:
            true,

          maintainAspectRatio:
            true

        }

      }
    );

}


/* =========================
   STRENGTH FORM
========================= */

document
  .getElementById("strengthForm")
  .addEventListener(
    "submit",
    function (event) {

      event.preventDefault();


      if (
        profile.trainingType !==
        "powerlifting"
      ) {

        alert(
          "Strength tracking is for Powerlifting."
        );

        return;

      }


      const record = {

        date:
          new Date()
            .toLocaleDateString(),

        bench:
          Number(
            document
              .getElementById("newBench")
              .value
          ) || profile.bench,

        squat:
          Number(
            document
              .getElementById("newSquat")
              .value
          ) || profile.squat,

        deadlift:
          Number(
            document
              .getElementById("newDeadlift")
              .value
          ) || profile.deadlift

      };


      strengthHistory.push(
        record
      );


      localStorage.setItem(

        "strengthHistory",

        JSON.stringify(
          strengthHistory
        )

      );


      renderStrengthChart();


      this.reset();

    }
  );


/* =========================
   STRENGTH CHART
========================= */

function renderStrengthChart() {

  const section =
    document.getElementById(
      "strengthProgress"
    );


  if (
    profile.trainingType !==
    "powerlifting"
  ) {

    section.style.display =
      "none";

    return;

  }


  section.style.display =
    "block";


  const latest =

    strengthHistory.length > 0

      ? strengthHistory[
          strengthHistory.length - 1
        ]

      : {

          bench:
            profile.bench,

          squat:
            profile.squat,

          deadlift:
            profile.deadlift

        };


  const total =

    latest.bench +

    latest.squat +

    latest.deadlift;


  document
    .getElementById(
      "powerliftingTotal"
    )
    .textContent =
    total;


  const canvas =
    document.getElementById(
      "strengthChart"
    );


  if (
    strengthChart
  ) {

    strengthChart.destroy();

  }


  strengthChart =
    new Chart(
      canvas,
      {

        type:
          "line",

        data: {

          labels:

            strengthHistory.map(
              item =>
                item.date
            ),

          datasets: [

            {

              label:
                "Bench",

              data:

                strengthHistory.map(
                  item =>
                    item.bench
                )

            },

            {

              label:
                "Squat",

              data:

                strengthHistory.map(
                  item =>
                    item.squat
                )

            },

            {

              label:
                "Deadlift",

              data:

                strengthHistory.map(
                  item =>
                    item.deadlift
                )

            }

          ]

        },

        options: {

          responsive:
            true

        }

      }
    );

}


/* =========================
   PROFILE
========================= */

function renderProfile() {

  const container =
    document.getElementById(
      "profileInfo"
    );


  container.innerHTML = `

    <p>
      <strong>Name:</strong>
      ${profile.name}
    </p>

    <p>
      <strong>Age:</strong>
      ${profile.age}
    </p>

    <p>
      <strong>Height:</strong>
      ${profile.height} cm
    </p>

    <p>
      <strong>Weight:</strong>
      ${profile.weight} kg
    </p>

    <p>
      <strong>Training:</strong>
      ${profile.trainingType}
    </p>

    <p>
      <strong>Level:</strong>
      ${profile.level}
    </p>

  `;


  document
    .getElementById(
      "targetCalories"
    )
    .value =
    targets.calories;


  document
    .getElementById(
      "targetProtein"
    )
    .value =
    targets.protein;


  document
    .getElementById(
      "targetCarbs"
    )
    .value =
    targets.carbs;


  document
    .getElementById(
      "targetFat"
    )
    .value =
    targets.fat;

}


/* =========================
   TARGET FORM
========================= */

document
  .getElementById("targetForm")
  .addEventListener(
    "submit",
    function (event) {

      event.preventDefault();


      targets = {

        calories:
          Number(
            document
              .getElementById(
                "targetCalories"
              )
              .value
          ),

        protein:
          Number(
            document
              .getElementById(
                "targetProtein"
              )
              .value
          ),

        carbs:
          Number(
            document
              .getElementById(
                "targetCarbs"
              )
              .value
          ),

        fat:
          Number(
            document
              .getElementById(
                "targetFat"
              )
              .value
          )

      };


      localStorage.setItem(

        "nutritionTargets",

        JSON.stringify(
          targets
        )

      );


      renderDashboard();


      alert(
        "Targets Saved!"
      );

    }
  );


/* =========================
   NAVIGATION
========================= */

document
  .querySelectorAll(
    ".nav-btn"
  )
  .forEach(
    button => {

      button.addEventListener(
        "click",
        () => {

          const page =
            button.dataset.page;


          document
            .querySelectorAll(
              ".page"
            )
            .forEach(
              pageElement =>

                pageElement.classList.remove(
                  "active"
                )

            );


          document
            .getElementById(
              page
            )
            .classList.add(
              "active"
            );


          document
            .querySelectorAll(
              ".nav-btn"
            )
            .forEach(
              navButton =>

                navButton.classList.remove(
                  "active"
                )

            );


          button.classList.add(
            "active"
          );

        }
      );

    }
  );


/* =========================
   SAVE ALL DATA
========================= */

function saveAll() {

  localStorage.setItem(

    "powerTrackProfile",

    JSON.stringify(
      profile
    )

  );


  localStorage.setItem(

    "powerTrackFoods",

    JSON.stringify(
      foods
    )

  );


  localStorage.setItem(

    "weightHistory",

    JSON.stringify(
      weightHistory
    )

  );


  localStorage.setItem(

    "strengthHistory",

    JSON.stringify(
      strengthHistory
    )

  );


  localStorage.setItem(

    "nutritionTargets",

    JSON.stringify(
      targets
    )

  );


  localStorage.setItem(

    "workoutPlan",

    JSON.stringify(
      workoutPlan
    )

  );

}


/* =========================
   RESET APP
========================= */

document
  .getElementById("resetApp")
  .addEventListener(
    "click",
    () => {

      const confirmReset =
        confirm(
          "Are you sure? All data will be deleted."
        );


      if (
        !confirmReset
      ) {

        return;

      }


      localStorage.clear();


      location.reload();

    }
  );


/* =========================
   START APP
========================= */

initializeApp();